"""Testes automatizados do BarberAgenda (executar com:  python -m pytest -v)."""
import os
import sys
from datetime import date, timedelta

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import create_app  # noqa: E402
from database import conectar  # noqa: E402

AMANHA = (date.today() + timedelta(days=1)).isoformat()
ONTEM = (date.today() - timedelta(days=1)).isoformat()


@pytest.fixture
def app(tmp_path):
    return create_app({"TESTING": True, "DATABASE": str(tmp_path / "teste.db")})


@pytest.fixture
def cliente_http(app):
    return app.test_client()


@pytest.fixture
def logado(cliente_http):
    cliente_http.post("/login", data={"login": "atendente", "senha": "barbearia123"})
    return cliente_http


def contar(app, tabela, where="1=1", params=()):
    conexao = conectar(app.config["DATABASE"])
    total = conexao.execute(f"SELECT COUNT(*) FROM {tabela} WHERE {where}", params).fetchone()[0]
    conexao.close()
    return total


def cadastrar(http, nome="João Pereira", telefone="(11) 98765-4321"):
    return http.post("/clientes/novo", data={"nome": nome, "telefone": telefone},
                     follow_redirects=True)


def agendar(http, hora="10:00", servico_id=3, profissional_id=1, data=AMANHA, cliente_id=1):
    return http.post("/agendamentos/novo", data={
        "cliente_id": cliente_id, "servico_id": servico_id,
        "profissional_id": profissional_id, "data": data, "hora": hora,
    }, follow_redirects=True)


# CT01 - Login com credenciais válidas
def test_ct01_login_valido(cliente_http):
    resposta = cliente_http.post("/login", data={"login": "atendente", "senha": "barbearia123"},
                                 follow_redirects=True)
    assert resposta.status_code == 200
    assert "Agenda do dia" in resposta.get_data(as_text=True)


# CT02 - Login com senha incorreta
def test_ct02_login_invalido(cliente_http):
    resposta = cliente_http.post("/login", data={"login": "atendente", "senha": "errada"})
    assert resposta.status_code == 401
    assert "Usuário ou senha inválidos." in resposta.get_data(as_text=True)


# CT03 - Acesso a uma tela interna sem login
def test_ct03_acesso_sem_login_redireciona(cliente_http):
    resposta = cliente_http.get("/agenda")
    assert resposta.status_code == 302
    assert "/login" in resposta.headers["Location"]


# CT04 - Cadastro de cliente com dados válidos
def test_ct04_cadastro_cliente_valido(app, logado):
    resposta = cadastrar(logado)
    html = resposta.get_data(as_text=True)
    assert "Cliente João Pereira cadastrado com sucesso!" in html
    assert "(11) 98765-4321" in html
    assert contar(app, "cliente", "telefone = ?", ("11987654321",)) == 1


# CT05 - Cadastro sem preencher o nome
def test_ct05_cadastro_sem_nome(app, logado):
    resposta = cadastrar(logado, nome="   ")
    assert resposta.status_code == 400
    assert "O nome do cliente é obrigatório." in resposta.get_data(as_text=True)
    assert contar(app, "cliente") == 0


# CT06 - Cadastro com telefone inválido
def test_ct06_telefone_invalido(app, logado):
    resposta = cadastrar(logado, telefone="1234")
    assert resposta.status_code == 400
    assert "Informe um telefone válido com DDD" in resposta.get_data(as_text=True)
    assert contar(app, "cliente") == 0


# CT07 - Cadastro com telefone já existente
def test_ct07_telefone_duplicado(app, logado):
    cadastrar(logado)
    resposta = cadastrar(logado, nome="Outro Cliente", telefone="11987654321")
    assert resposta.status_code == 400
    assert "Já existe um cliente cadastrado com este telefone." in resposta.get_data(as_text=True)
    assert contar(app, "cliente") == 1


# CT08 - Agendamento em horário livre
def test_ct08_agendamento_horario_livre(app, logado):
    cadastrar(logado)
    resposta = agendar(logado, hora="10:00")
    html = resposta.get_data(as_text=True)
    assert "Agendamento confirmado" in html
    assert "10:00" in html and "11:00" in html          # corte + barba = 60 min
    assert contar(app, "agendamento", "status = 'AGENDADO'") == 1


# CT09 - Agendamento em horário já ocupado (mesmo profissional)
def test_ct09_agendamento_horario_ocupado(app, logado):
    cadastrar(logado)
    agendar(logado, hora="10:00")                          # ocupa 10:00-11:00
    resposta = agendar(logado, hora="10:30", servico_id=1)  # 10:30-11:00 se sobrepõe
    assert resposta.status_code == 400
    assert "Horário indisponível" in resposta.get_data(as_text=True)
    assert contar(app, "agendamento") == 1


# CT10 - Mesmo horário com OUTRO profissional deve ser permitido
def test_ct10_mesmo_horario_outro_profissional(app, logado):
    cadastrar(logado)
    agendar(logado, hora="10:00", profissional_id=1)
    resposta = agendar(logado, hora="10:00", profissional_id=2)
    assert "Agendamento confirmado" in resposta.get_data(as_text=True)
    assert contar(app, "agendamento") == 2


# CT11 - Agendamento em data passada
def test_ct11_agendamento_data_passada(app, logado):
    cadastrar(logado)
    resposta = agendar(logado, data=ONTEM)
    assert resposta.status_code == 400
    assert "Não é possível agendar em uma data passada." in resposta.get_data(as_text=True)
    assert contar(app, "agendamento") == 0


# CT12 - Agendamento fora do horário de funcionamento
def test_ct12_fora_do_expediente(app, logado):
    cadastrar(logado)
    resposta = agendar(logado, hora="18:30")              # 60 min terminaria 19:30
    assert resposta.status_code == 400
    assert "O atendimento deve ocorrer entre 09:00 e 19:00." in resposta.get_data(as_text=True)


# CT13 - Cancelar agendamento libera o horário
def test_ct13_cancelar_libera_horario(app, logado):
    cadastrar(logado)
    agendar(logado, hora="10:00")
    resposta = logado.post("/agendamentos/1/cancelar", follow_redirects=True)
    assert "Agendamento cancelado. O horário foi liberado." in resposta.get_data(as_text=True)
    assert contar(app, "agendamento", "status = 'CANCELADO'") == 1
    nova = agendar(logado, hora="10:00")
    assert "Agendamento confirmado" in nova.get_data(as_text=True)


# CT14 - Consultar agenda de um dia sem agendamentos
def test_ct14_agenda_vazia(logado):
    resposta = logado.get(f"/agenda?data={AMANHA}")
    assert resposta.status_code == 200
    assert "Nenhum agendamento para esta data" in resposta.get_data(as_text=True)


# CT15 - Busca de cliente pelo nome
def test_ct15_busca_cliente(logado):
    cadastrar(logado, nome="João Pereira", telefone="11987654321")
    cadastrar(logado, nome="Rafael Lima", telefone="11912345678")
    html = logado.get("/clientes?busca=Rafa").get_data(as_text=True)
    assert "Rafael Lima" in html and "João Pereira" not in html
